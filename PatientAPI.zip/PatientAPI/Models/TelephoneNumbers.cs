﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PatientAPI.Models
{
    public class TelephoneNumbers
    {
        public int Homenumber { get; set; }
        public int Worknumber { get; set; }
        public int Mobilenumber { get; set; }
    }
}