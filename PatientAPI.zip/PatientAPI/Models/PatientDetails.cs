﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PatientAPI.Models
{
    public class PatientDetails                 //this class represents the patient inventory/table. this is the base table for all queries
    {
        public int PatientID { get; set; }
        public string Forename { get; set; }
        public string Surname { get; set; }
        public int Dateofbirth { get; set; }
        public string Gender { get; set; }
        public List<int> PhnnumberList = new List<int>();       //using a list to store home/work/cell phone numbers instead of a table....my bad

        public static List<PatientDetails> patientList = new List<PatientDetails>();
        private static readonly object lockobj = new object();
        private static PatientDetails patientHandler=null;
        public static PatientDetails PatientHandler 
        {
            //singleton object with threadsafe since each call to the server should get the same instance of the patient table
            get 
            {
                if (patientHandler == null)
                {
                    lock (lockobj)
                    {
                        if (patientHandler == null)
                        {
                            patientHandler = new PatientDetails();
                        }
                    }
                }
                return patientHandler;
            }
        }

        public static void LoadPatientDetails ()
        {
            patientList.Clear();
            patientList.Add(new PatientDetails { PatientID = 1, Forename = "F1", Surname = "S1", Dateofbirth = 19900101, Gender = "Male", PhnnumberList = {  1111111, 22222222, 3333333 } });
            patientList.Add(new PatientDetails { PatientID = 2, Forename = "F2", Surname = "S2", Dateofbirth = 19900102, Gender = "Female", PhnnumberList = { 444444, 555555, 666666 } });
            patientList.Add(new PatientDetails { PatientID = 3, Forename = "F3", Surname = "S3", Dateofbirth = 19900103, Gender = "Male", PhnnumberList = { 777777, 888888, 999999 } });
        }
    }
}


