﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using PatientAPI.Models;
using Newtonsoft.Json;

namespace PatientAPI.Controllers
{
    //[Authorize]
    public class ValuesController : ApiController
    {
        // GET api/values
        public IEnumerable<PatientDetails> Get()
        {
            //return new string[] { "value1", "value2" };
            return PatientDetails.patientList;
        }

        // GET api/values/5
        public IEnumerable<PatientDetails> Get(int id)
        {
            //return "value";
            return PatientDetails.patientList.Where(n => n.PatientID == id).ToList<PatientDetails>();
        }

        public IEnumerable<PatientDetails> Get(string loadstr)
        {
            PatientDetails.LoadPatientDetails();
            string temp=JsonConvert.SerializeObject(PatientDetails.patientList);
            return PatientDetails.patientList;
        }

        // POST api/values
        public void Post([FromBody]PatientDetails value)
        {
            PatientDetails.patientList.Add(value);
            
        }

        // PUT api/values/5
        public void Put([FromBody]List<PatientDetails> value)
        {
            PatientDetails.patientList = value;

            //foreach (var p in PatientDetails.patientList.Where(x => x.PatientID == id))
            //{
            //    p.PatientID = p.PatientID;
            //    p.Forename = p.Forename;
            //    p.Surname = p.Surname;
            //    p.Dateofbirth = p.PatientID;
            //    p.Gender = p.Gender;
            //}
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
            PatientDetails.patientList.RemoveAll(x => x.PatientID == id);
        }
    }
}
