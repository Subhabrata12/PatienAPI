﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(PatientClient.Startup))]
namespace PatientClient
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
