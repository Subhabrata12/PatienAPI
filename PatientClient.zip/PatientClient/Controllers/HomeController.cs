﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PatientClient.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ConnectAPIClass conapi = ConnectAPIClass.ConAPIHandler;
            string temp=conapi.ConnectAPIonLoad(true);

            List<Patient> patientList = conapi.JSONtoObect<Patient>(temp);
            ViewBag.patientListing = patientList;
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public string Index2()
        {
            ConnectAPIClass conapi = ConnectAPIClass.ConAPIHandler;
            string temp = conapi.ConnectAPIonLoad(true);
            return temp;
        }

        public string invokeGet()
        {
            ConnectAPIClass conapi = ConnectAPIClass.ConAPIHandler;
            string temp = conapi.ConnectAPIonLoad(false);
            return temp;
        }

        public string invokePOST(string str)
        {
            ConnectAPIClass conapi = ConnectAPIClass.ConAPIHandler;
            string temp = conapi.ConnectAPItoPOST(str);
            return temp;
        }

        public string invokePUT(string idstr, string objstr)
        {
            ConnectAPIClass conapi = ConnectAPIClass.ConAPIHandler;
            string temp = conapi.ConnectAPItoPUT(idstr,objstr);
            return temp;
        }

        public string invokeDELETE(string idstr)
        {
            ConnectAPIClass conapi = ConnectAPIClass.ConAPIHandler;
            string temp = conapi.ConnectAPItoDELETE(idstr);
            return temp;
        }


    }
}