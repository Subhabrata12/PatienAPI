﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Text;

namespace PatientClient.Controllers
{
    public class ConnectAPIClass
    {
        private string baseURL = string.Empty;
        private string postURL = string.Empty;
        private static HttpClient client = null;

        private static ConnectAPIClass conapiHandler = null;
        public static ConnectAPIClass ConAPIHandler 
        {
            //singleton object without threadsafe 
            get
            {
                if (conapiHandler == null)
                {
                    conapiHandler = new ConnectAPIClass();
                }
                return conapiHandler;
            }
        }


        public ConnectAPIClass()
        {
            baseURL = ConfigurationManager.AppSettings["APIbaseURL"].ToString();
            postURL = ConfigurationManager.AppSettings["APIpostURL"].ToString();
            
        }

        public string ConnectAPIonLoad(bool screenRefresh)
        {//this is different than what i did in office...still working
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(baseURL);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //var response = client.GetAsync(postURL + "?loadstr=value");
            string postingurl = string.Empty;               //initial load refreshes the table to original state, changes lost
            if (screenRefresh)
                postingurl=postURL + "?loadstr=value";
            else
                postingurl=postURL;

            var response = client.GetAsync(postingurl).Result;
            //response.Wait();
            //var result = response.Result;
            if (response.IsSuccessStatusCode)
            {
                
                //var responsestr = result.Content.ReadAsStringAsync();
                Task<string> responsestr = response.Content.ReadAsStringAsync();
                //responsestr.Wait();

                return responsestr.Result;
            }
            else
            {
                var responsestr = response.Content.ReadAsStringAsync();
                responsestr.Wait();

                return responsestr.Result;
            }
        }

        public string ConnectAPItoPOST(string str) 
        {
            //str = "{\"value\"=" + str + "}";
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(baseURL);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            StringContent content = new StringContent(str, Encoding.UTF8, "application/json");
            var response = client.PostAsync(postURL,content).Result;
            //response.Wait();
            //var result = response.Result;
            if (response.IsSuccessStatusCode)
            {

                //var responsestr = result.Content.ReadAsStringAsync();
                Task<string> responsestr = response.Content.ReadAsStringAsync();
                //responsestr.Wait();

                return responsestr.Result;
            }
            else
            {
                var responsestr = response.Content.ReadAsStringAsync();
                responsestr.Wait();

                return responsestr.Result;
            }
            
        }

        public string ConnectAPItoPUT(string idstr, string objstr)
        {
            //str = "{\"value\"=" + str + "}";
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(baseURL);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            StringContent content = new StringContent(objstr, Encoding.UTF8, "application/json");
            var response = client.PutAsync(postURL, content).Result;
            //response.Wait();
            //var result = response.Result;
            if (response.IsSuccessStatusCode)
            {

                //var responsestr = result.Content.ReadAsStringAsync();
                Task<string> responsestr = response.Content.ReadAsStringAsync();
                //responsestr.Wait();

                return responsestr.Result;
            }
            else
            {
                var responsestr = response.Content.ReadAsStringAsync();
                responsestr.Wait();

                return responsestr.Result;
            }

        }

        public string ConnectAPItoDELETE(string idstr)
        {
            //str = "{\"value\"=" + str + "}";
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(baseURL);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var response = client.DeleteAsync(postURL+"?id="+idstr).Result;
            //response.Wait();
            //var result = response.Result;
            if (response.IsSuccessStatusCode)
            {

                //var responsestr = result.Content.ReadAsStringAsync();
                Task<string> responsestr = response.Content.ReadAsStringAsync();
                //responsestr.Wait();

                return responsestr.Result;
            }
            else
            {
                var responsestr = response.Content.ReadAsStringAsync();
                responsestr.Wait();

                return responsestr.Result;
            }

        }


        public List<T> JSONtoObect<T>(string jsonstr)
        {//creating a generic method to deserialize to any object. right now only Patient type
            List<T> listobj = JsonConvert.DeserializeObject<List<T>>(jsonstr);
            return listobj;
        }


    }
}