﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PatientClient.Controllers
{
    public class Patient
    {
        public int PatientID { get; set; }
        public string Forename { get; set; }
        public string Surname { get; set; }
        public int Dateofbirth { get; set; }
        public string Gender { get; set; }
        public List<int> PhnnumberList = new List<int>();       //using a list to store home/work/cell phone numbers instead of a table....my bad
    }
}